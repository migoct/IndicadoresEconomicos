package com.dissolucion.indicadoreseconomicos.core.utils

object Constants {
    const val BASE_URL = "https://mindicador.cl/api/"
}
