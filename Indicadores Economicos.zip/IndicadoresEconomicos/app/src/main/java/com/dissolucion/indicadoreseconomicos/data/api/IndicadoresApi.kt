package com.dissolucion.indicadoreseconomicos.data.api

import com.dissolucion.indicadoreseconomicos.data.dto.todos.IndicadoresDto
import retrofit2.Call
import retrofit2.http.GET

interface IndicadoresApi {

    @GET("/")
    suspend fun getIndicadores(): IndicadoresDto
}
