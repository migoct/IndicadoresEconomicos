package com.dissolucion.indicadoreseconomicos

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class IndicadoresApplication: Application()